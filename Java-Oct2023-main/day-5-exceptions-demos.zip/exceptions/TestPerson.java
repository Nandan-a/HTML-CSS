package com.hsbc.exceptions;

public class TestPerson {
	
	public static void main(String[] args) {
		Person p = new Person();
		try {
		   p.setPid(-100);
		}
		catch(InvalidPersonIdException e) {
			System.out.println(e.getMessage());
		}
		
		p.setPname("Prachi");
		
		System.out.println(p);
	}

}
