package com.hsbc.exceptions;

public class ExcpDemo {

	public static void main(String[] args) {

		try {
			System.out.println("in try-before");
			int c = 10 / 0;
			System.out.println("in try-after");
		}

		catch (ArithmeticException e) {
			System.out.println("In catch");
			System.out.println(e.getMessage());
		}
		System.out.println("After try-catch");
	}
}
