package com.hsbc.exceptions;

public class Person {
	
	int pid;
	String pname;
	
	
	public void setPid(int pid) throws InvalidPersonIdException{
		if(pid < 1)
			throw new InvalidPersonIdException("Person id is invalid");
		this.pid = pid;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + "]";
	}

}
