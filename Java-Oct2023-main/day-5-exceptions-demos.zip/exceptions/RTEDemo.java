package com.hsbc.exceptions;

import java.util.Scanner;

public class RTEDemo {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter value for a");
		int a = sc.nextInt();
		
		System.out.println("Enter value for b");
		int b = sc.nextInt();
		
		if(b == 0)
			throw new InvalidValueException("Denominator cannot be 0!!");
		
		int  c = a/b;
		System.out.println(c);
		
	}

}
