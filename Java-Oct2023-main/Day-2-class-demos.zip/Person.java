package com.hsbc;

public class Person {
	
	int pid;
	String personName;
	Date dob;
	
	public Person(int pid, String personName, Date dob) {
		this.pid = pid;
		this.personName = personName;
		this.dob = dob;
	}

	public String toString() {
		return "Person [pid=" + pid + ", personName=" + personName + ", dob=" + dob + "]";
	}
	
	public static void main(String[] args) {
		
		Date d1 = new Date(4,10,2023);
		
		Person p1 = new Person(101, "Prachi", d1);
		System.out.println(p1);
			
	}	
}
