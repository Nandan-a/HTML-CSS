package com.hsbc;

import java.util.Scanner;

public class ArrayDemo {
	
	public static void main(String[] args) {
		
//		int arr[] = new int[5];
//		arr[0] = 101;
//		arr[1] = 201;
//		arr[2] = 301;
//		arr[3] = 401;
//		arr[4] = 501;
//		
//		for(int i = 0 ; i < arr.length; i++) {
//			System.out.println(arr[i]);
//		}
//		
//		//Java 5 : enhanced for loop
//		for(int ele : arr)
//			System.out.println(ele);
		
		
		int arr[] = {10,20,30,40,50};
		
		for(int i = 0 ; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		System.out.println(arr[5]);
		
		//double[] temps = new double[5];
//		float[] temps = {20.4f, 34.5f, 33.2f, 45.4f, 25.5f};
//		
//		for(float temp : temps)
//			System.out.println(temp);
//		
//		
//		//char[] carr = new char[5];
//		//carr[0] = 'a';
//		
//		char[] carr = {'2', '*',' ','g', '%'};
//		for(char c : carr)
//			System.out.println(c);
//		
//		
//		//String[] names = new String[3];
//		//names[0] = "Neervika";
//		
//		String names[] = {"Charu","Siya","Harshita","Rishita","Kritika"};
//		
//		for(String name : names)
//			System.out.println(name);
//		
//		System.out.println("-------------------------");
//		
//		int init = 100;
//		int[][] marr = new int[2][3];
//		
//		for(int i = 0 ; i < marr.length; i++) {
//			for(int j=0; j < marr[i].length; j++)
//				marr[i][j] = init++;
//		}
//		
//		for(int i = 0 ; i < marr.length; i++) {
//			for(int j=0; j < marr[i].length; j++)
//				System.out.println(marr[i][j]);
//		}
		
		
		
	}

}
