package com.hsbc;

public class Box {

	private int length, width, height;
	
	
	//cons overloading
	
	public Box() {}  //def no-arg cons
	
	public Box(int length, int width, int height) {  //parameterized cons
		this.length = length;
		this.width = width;
		this.height = height;
	}
	
	public String toString() {
		return "Box [length=" + length + ", width=" + width + ", height=" + height + "]";
	}
	
	public int calculateVol() {
		int vol = 0;
		vol = this.length * this.width * this.height;
		return vol;
	}

	
	
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public static void main(String[] args) {
		Box b1 = new Box(10,5,20);
		System.out.println(b1);
	}
}
