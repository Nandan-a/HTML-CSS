package com.hsbc;

public class TestBox {
	
	public static void main(String[] args) {
//		Box b1 = new Box(10,5,20);  //named objects
//		Box b2 = new Box(1,2,3);
//		Box b3 = new Box(100,200,300);
		
		
		//object arrays
		int[] arr = new int[5];
		
		Box[] boxes = new Box[3];
		
//		boxes[0] = b1;
//		boxes[1] = b2;
//		boxes[2] = b3;
		
		boxes[0] = new Box(10,5,20);   //anonymous objects
		boxes[1] = new Box(1,2,3);
		boxes[2] = new Box(100,200,300);
		
		//Box[] boxes = {b1, b2, b3};
		
		for(Box box : boxes) {
			System.out.print(box);
			System.out.println("   Volume : " + box.calculateVol());
		}
		
	}

}
