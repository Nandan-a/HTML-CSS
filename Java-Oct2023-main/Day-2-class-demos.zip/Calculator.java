package com.hsbc;

public class Calculator {
	
	// Method overloading  --> static polymorphism
	//Type of args or no of args will differ
	//return type has no significance
	
	public int add(int a, int b) {
		return a+b;
	}

	public String add(String a, String b) {
		return a+b;
	}
	
	public float add(float a, float b) {
		return a+b;
	}
	
	public int add(int a, int b, int c) {
		return a+b+c;
	}
	
	
	public static void main(String[] args) {
		Calculator calc = new Calculator();
		
		System.out.println(calc.add(10, 20));
		System.out.println(calc.add("aaa", "bbb"));
		System.out.println(calc.add(23.6f, 34.3f));
		System.out.println(calc.add(10, 20, 30));
	}

}
