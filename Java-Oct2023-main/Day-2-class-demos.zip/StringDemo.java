package com.hsbc;

public class StringDemo {
	
	public static void main(String[] args) {
		String s1 = "Hello World";
		
		String s2 = new String("Hello World");
		
		System.out.println(s1.length());  //11
		System.out.println(s1.charAt(7));  //o
		System.out.println(s1.indexOf("r"));  //8
		System.out.println(s1.indexOf("orl"));  //7
		System.out.println(s1.toUpperCase());
		System.out.println(s1.toLowerCase());
		
		int a = 10, b = 10;
		
		if(a == b) {}  // use == to compare primitives
		
		//if(s1 == s2)  //use equals() to compare objcets
		
		if(s1.equals(s2)) {
			System.out.println("equal");
		}
		
		String str = String.join(" | ", "aaa","bbb","ccc","dddd");
		System.out.println(str);  //aaa | bbb | ccc | dddd
		
		str.split("|");
		
		
		String s3 = "      Charu Gupta     ";
		System.out.println("|" + s3 + "|");
		System.out.println("|" + s3.strip() + "|");
		
		System.out.println("|" +s3.stripLeading() + "|");
		System.out.println("|" +s3.stripTrailing()+ "|");
		
		
		System.out.println("    ".isBlank());
		
		
	}

}
