package com.hsbc;

import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id");
		int id = sc.nextInt();

		sc.nextLine();
		System.out.println("Enter first name");

		String fname = sc.nextLine();
		
		sc.nextLine();

		System.out.println("Enter last name");

		String lname = sc.nextLine();

		System.out.println("Enter sal");
		double sal = sc.nextDouble();

		System.out.println("id : " + id + "   Name : " + fname + lname + "   Sal : " + sal);

	}

}
