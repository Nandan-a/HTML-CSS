package com.hsbc;

import java.util.Arrays;

public class MethodDemo {

	public void greet() {
		System.out.println("Hello World!!");
	}
	
	public void greetUser(String uname) {
		System.out.println("Hello " + uname);
	}
	
	public int add(int a, int b) {
		return a + b;
	}
	
	public int[] m1(int[] arr) {
		int[] sqarr = new int[arr.length];
		
		for(int i = 0 ; i< arr.length; i++) {
			sqarr[i] = arr[i] * arr[i];
		}
		return sqarr;	
	}
	
	public static void main(String[] args) {
		MethodDemo demo = new MethodDemo();
		//demo.greet();
		//demo.greetUser("Siya");
		//System.out.println("Sum is " + demo.add(10, 20));
		
		int[] myarr = {10,20,30,40,50};
		int[] resarr = demo.m1(myarr);
		
		System.out.println(Arrays.toString(resarr));
		
		
	}
}
