package com.hsbc;

public class Demo {
	
	public static void main(String[] args) {
		Box b1 = new Box(10,5,20);  //named objects
		Box b2 = new Box(1,2,3);
		Box b3 = b1;
		
		System.out.println(b3);
		b3.setHeight(100);
		b3.setLength(500);
		
		System.out.println(b1);
		
		if(b1 == b2)
			System.out.println("Same object!!");
		else
			System.out.println("NOT Same object!!");
		
	}

}
