package com.hsbc.bookapp.exceptions;

public class MaxLengthReachedException extends Exception{

	public MaxLengthReachedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MaxLengthReachedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MaxLengthReachedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MaxLengthReachedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MaxLengthReachedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
