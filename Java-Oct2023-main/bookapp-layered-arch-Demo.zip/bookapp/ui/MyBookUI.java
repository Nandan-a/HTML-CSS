package com.hsbc.bookapp.ui;

import java.util.Scanner;

import com.hsbc.bookapp.dao.BookDao;
import com.hsbc.bookapp.dao.BookDaoIntf;
import com.hsbc.bookapp.exceptions.BookNotFoundException;
import com.hsbc.bookapp.exceptions.MaxLengthReachedException;
import com.hsbc.bookapp.factory.DataStoreFactory;
import com.hsbc.bookapp.model.Book;

public class MyBookUI {
	// Menu driven application

	Book[] bookarr = null;
	BookDaoIntf dao = null;
	static Scanner sc = new Scanner(System.in);

	public MyBookUI() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of your data store");
		int size = sc.nextInt();
		bookarr = DataStoreFactory.getBookStore(size);
		dao = new BookDao(bookarr);

		this.menuMethod();
	}

	public void menuMethod() {

		while (true) {
			System.out.println("\n\n1. Fetch all books");
			System.out.println("2. Fetch book by id");
			System.out.println("3. Fetch book by author");
			System.out.println("4. Add Book");
			System.out.println("5. Update Book");
			System.out.println("6. Quit");
			System.out.println("Make your choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				fetchAllBooks(dao);
				break;
			case 2:
				fetchBookById(dao);
				break;
			case 3:
				break;
			case 4:
				addBook(dao);
				break;
			case 5:
				System.out.println();
				update(dao);
				break;
			case 6:
				System.exit(0);

				// default case to display the message invalid choice made by
				// the user
			default:
				System.out.println("Invalid choice!!! Please make a valid choice. \\n\\n");
			}

		}

	}

	public static void fetchAllBooks(BookDaoIntf dao2) {
		Book[] books = dao2.getAllBooks();
		for (Book b : books)
			System.out.println(b);
	}

	public static void fetchBookById(BookDaoIntf dao2) {
		System.out.println("Enter Bookid to search");
		int id = sc.nextInt();
		Book book = null;
		try {
			book = dao2.getBooksById(id);
		} catch (BookNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Book details : " + book);

	}

	public static void update(BookDaoIntf dao2) {
		System.out.println("Enter book details: \n Enter book id");
		int id = sc.nextInt();
		System.out.println("Enter Book Name");
		String bname = sc.nextLine();
		sc.nextLine();
		System.out.println("Enter Author");
		String auth = sc.nextLine();
		System.out.println("Enter Price");
		float price = sc.nextFloat();
		Book b = new Book(id, bname, auth, price);
		dao2.updateBook(b);
	}
	
	public static void addBook(BookDaoIntf dao2) {
		System.out.println("Enter book details: \n Enter book id");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Book Name");
		String bname = sc.nextLine();
		sc.nextLine();
		System.out.println("Enter Author");
		String auth = sc.nextLine();
		System.out.println("Enter Price");
		float price = sc.nextFloat();
		Book b = new Book(id, bname, auth, price);
		try {
			dao2.addBook(b);
		} catch (MaxLengthReachedException e) {
			System.out.println(e.getMessage());
		}
	}

}
