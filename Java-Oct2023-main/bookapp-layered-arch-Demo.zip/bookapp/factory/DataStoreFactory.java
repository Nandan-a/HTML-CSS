package com.hsbc.bookapp.factory;

import com.hsbc.bookapp.model.Book;

public class DataStoreFactory {
	
	public static Book[] getBookStore(int size) {
		return new Book[size];
	}

}
