package com.hsbc.bookapp.dao;

import com.hsbc.bookapp.exceptions.BookNotFoundException;
import com.hsbc.bookapp.exceptions.MaxLengthReachedException;
import com.hsbc.bookapp.model.Book;


//CRUD : Create Read Update Delete
//DAO - Data Access object

public interface BookDaoIntf {
	
	public Book[] getAllBooks();
	
	public Book getBooksById(int bookid) throws BookNotFoundException;
	
	public Book[] getBooksByAuthor(String author);
	
	public void updateBook(Book book);
	
	public void addBook(Book book) throws MaxLengthReachedException;
	
}
