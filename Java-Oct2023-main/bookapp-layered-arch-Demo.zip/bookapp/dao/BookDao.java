package com.hsbc.bookapp.dao;

import java.util.Arrays;

import com.hsbc.bookapp.exceptions.BookNotFoundException;
import com.hsbc.bookapp.exceptions.MaxLengthReachedException;
import com.hsbc.bookapp.model.Book;

public class BookDao implements BookDaoIntf{
	
	private Book[] booklist;

	public BookDao(Book[] booklist) {
		this.booklist = booklist;
		booklist[0] = new Book(1,"book1", "author1", 200);
		booklist[1] = new Book(2,"book2", "author2", 400);
		booklist[2] = new Book(3,"book3", "author3", 500);
		booklist[3] = new Book(4,"book4", "author3", 500);
		booklist[4] = new Book(5,"book5", "author1", 500);
	}

	public Book[] getAllBooks() {
		return booklist;
	}

	public Book getBooksById(int bookid) throws BookNotFoundException{
		Book foundbook = null;
		boolean flag=false;
		
		for(Book book : booklist) {
			if(book.getBookId() == bookid) {
				flag=true;
				foundbook = book;
			}
		}
		
		if(flag)
			return foundbook;
		else
			throw new BookNotFoundException("Book with id " + bookid + "  not found!");		
	}

	public Book[] getBooksByAuthor(String author) {
		int counter = 0;
		Book[] authorlist = null;
		int index=0;
		
		for(Book book : booklist) {
			if(book.getAuthor().equals(author))
				++counter;
		}
		
		for(Book book : booklist) {
			if(book.getAuthor().equals(author)) {
				authorlist[index] = book;
				index++;
			}
		}
		
		return authorlist;
		
	}

	public void updateBook(Book book) {
		for(Book b : booklist) {
			if(b.getBookId() == book.getBookId()) {
				b.setAuthor(book.getAuthor());
				b.setBookName(book.getBookName());
				b.setPrice(book.getPrice());
			}
		}
	}

	public void addBook(Book book) throws MaxLengthReachedException{
		if(booklist.length > 7)
			throw new MaxLengthReachedException("Book store Limit is exceeded!!");
		booklist = Arrays.copyOf(booklist, booklist.length + 1);
		booklist[booklist.length - 1] = book;
	}
}







