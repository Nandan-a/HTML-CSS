package com.hsbc.bookapp.tester;

import com.hsbc.bookapp.ui.MyBookUI;

public class TestBookApp {
	
	public static void main(String[] args) {
		MyBookUI ui = new MyBookUI();
	}

}
