package com.hsbc.day3;

public class Emp {
	
	int empId=1;   
	String empName, desig;  //instance var
	double sal;
	static int counter = 0;
	
	public Emp(){
		this.empId = counter++;
	}

	public Emp(String empName) {
		this.empId = counter++;
		this.empName = empName;
	}

	public Emp(String empName, String desig, double sal) {
		this.empId = counter++;
		this.empName = empName;
		this.desig = desig;
		this.sal = sal;
	}
	
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", desig=" + desig + ", sal=" + sal + "]";
	}

	public static void main(String[] args) {
		Emp e1 = new Emp();
		Emp e2 = new Emp("Kritika");
		Emp e3 = new Emp("Charu","SSE", 90000);
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
	}

}
