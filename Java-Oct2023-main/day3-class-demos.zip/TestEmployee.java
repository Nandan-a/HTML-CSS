package com.hsbc.day3;

public class TestEmployee {
	
	public static void main(String[] args) {
		
		Employee e1 = new Employee(1, "aaa");
		Employee e2 = new WageEmp(2, "bbbb", 100, 100);
		Employee e3 = new SalesEmp(3, "ccc", 80, 10, 250);
		
		//Polymorphic Behaviour
		
		Employee[] empArr = {e1, e2, e3};
		
		for(Employee emp : empArr) {
			//emp.displayEmpDetails();
		}
		
		//Loop thru the array and display salary of all emps, for Employee display _ no sal applicable
		
		for(Employee emp : empArr) {
			if(emp instanceof SalesEmp)
				System.out.println(((SalesEmp)emp).calcSalary());
			else if(emp instanceof WageEmp)
				System.out.println(((WageEmp) emp).calcSalary());
			else if(emp instanceof Employee)
				System.out.println("Sal not applicable!!");
		}
	}

}









