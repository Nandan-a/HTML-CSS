package com.hsbc.day3;

public class SalesEmp extends WageEmp {
	
	int comm;

	public SalesEmp() {	}

	public SalesEmp(int empId, String empName, int hrs, int rate, int comm) {
		super(empId, empName, hrs, rate);
		this.comm = comm;
	}
	
	public int calcSalary() {  //method overriding
		return comm + super.calcSalary();
	}
	
}









