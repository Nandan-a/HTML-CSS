package com.hsbc.day3;

public class Point extends Shape{
	
	public void draw() {   //method implementation
		System.out.println("Drawing a point!!!");
	}
	
	public static void main(String[] args) {
		Shape p = new Point();
		p.draw();
		p.setColor("blue");
		p.getColor();
		
		//Shape s = new Shape(); //abstarct can never be instantiated
	}
	
}
