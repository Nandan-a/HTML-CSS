package com.hsbc.day3;

public class Circle extends Point{

	public void draw() {
		System.out.println("Drawing a  circle");
	}

	
}
