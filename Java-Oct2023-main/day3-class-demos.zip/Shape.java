package com.hsbc.day3;

public abstract class Shape {
	
	String color;

	public String getColor() {  //concrete methods - that contain impl
		return color;
	}

	public void setColor(String color) {  //concrete methods - that contain impl
		this.color = color;
	}
	
	public abstract void draw();  //abstarct method
	
}
