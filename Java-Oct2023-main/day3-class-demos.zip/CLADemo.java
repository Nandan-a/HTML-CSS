package com.hsbc.day3;

public class CLADemo {
	
	public static void main(String[] args) {
		
		int a = Integer.parseInt(args[0]);
		
	}
	
   
}
