package com.hsbc.day3;

public class Painter {
	
	public static void drawIt(Shape obj) {
		obj.draw();
	}
	
	public static void main(String[] args) {
		Shape s1 = new Point();
		Shape s2 = new Circle();
		
		drawIt(s1);
		drawIt(s2);
		
	}

}
