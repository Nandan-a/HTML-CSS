package com.hsbc.day3;

public class WageEmp extends Employee{
	
	int hrs, rate;
	
	public WageEmp() {}
	
	
	public WageEmp(int empId, String empName, int hrs, int rate) {
		super(empId, empName);
		this.hrs = hrs;
		this.rate = rate;	
	}
	
	public int calcSalary() {
		return rate * hrs;
	}

	public void displayEmpDetails() {
		super.displayEmpDetails();
		System.out.println("  Emp Sal : " + this.calcSalary());
	}
	
}
