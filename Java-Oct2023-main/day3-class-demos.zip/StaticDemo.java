package com.hsbc.day3;

public class StaticDemo {
	
	int i = 10;
	static int j = 20;
	
	public void m1() {
		System.out.println("in m1() " + i + "  " + j);
	}
	
	public static void m2() {
		System.out.println("in m2() " );
		m3();
	}
	
	public static void m3() {
		System.out.println("in m3() " );
		m2();
	}

	
	public static void main(String[] args) {
		StaticDemo sd = new StaticDemo();
		
		
	}
}
