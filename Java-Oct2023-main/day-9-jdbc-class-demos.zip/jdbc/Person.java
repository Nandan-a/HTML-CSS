package com.hsbc.jdbc;

public class Person {

	int pid;
	String pname, city;

	public Person() {
	}

	public Person(int pid, String pname, String city) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.city = city;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pname=" + pname + ", city=" + city + "]";
	}

}
