package com.hsbc.jdbc;

import java.sql.*;

public class PersonDao implements PersonDaoIntf{
	
	Connection conn=null;
	
	public Connection getConn() {
		String url = "jdbc:mysql://localhost:3306/trgdb";
		
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			conn = DriverManager.getConnection(url, "root", "root123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public PersonDao(){
		conn = this.getConn();
	}

	
	//String sql = "insert into person values(107,'Vani','Knp')";
	
	public void addPerson(Person p) throws SQLException {
		//Statement stmt = conn.createStatement();
		//String sql = "insert into person values(" + p.getPid() + ",'" + p.getPname() + "','" + p.getCity() + "')";
		
		String sql = "insert into person values(?,?,?)";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, p.getPid());
		pstmt.setString(2, p.getPname());
		pstmt.setString(3, p.getCity());
		
		pstmt.executeUpdate();
	}

	@Override
	public void delPerson(int pid) throws SQLException {
		//Statement stmt = conn.createStatement();
		
		//String sql = "delete from person where pid = " + pid;
		
		String sql = "delete from person where pid = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, pid);
		
		pstmt.executeUpdate();
	}

	@Override
	public void updatePerson(Person p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayAllPersons() {
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		PersonDaoIntf dao = new PersonDao();
		try {
			dao.addPerson(new Person(111,"Neervika", "Blore"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			dao.delPerson(105);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

}





