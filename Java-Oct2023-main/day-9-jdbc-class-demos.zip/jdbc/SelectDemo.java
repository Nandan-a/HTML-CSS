package com.hsbc.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {
	
	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/trgdb";
		
		String sql = "select * from person";
		
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			Connection conn = DriverManager.getConnection(url, "root", "root123");
			
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
			System.out.println(rs.getInt(1) + "    " + rs.getString(2) + "    " + rs.getString(3));
			
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
