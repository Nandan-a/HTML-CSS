package com.hsbc.jdbc;

import java.sql.SQLException;

public interface PersonDaoIntf {
	
	public void addPerson(Person p) throws SQLException;
	public void delPerson(int pid) throws SQLException;
	public void updatePerson(Person p) throws SQLException;
	public void displayAllPersons() throws SQLException;

}
