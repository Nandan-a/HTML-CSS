package com.hsbc.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateDemo {
	
	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/trgdb";
		
		String sql = "update person set city='Mumbai' where pid=102";
		
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			Connection conn = DriverManager.getConnection(url, "root", "root123");
			
			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			if(count > 0)
				System.out.println("Update is succesful!!");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
