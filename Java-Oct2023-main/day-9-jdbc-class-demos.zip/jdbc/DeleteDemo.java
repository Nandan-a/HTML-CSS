package com.hsbc.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteDemo {
	
	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/trgdb";
		
		//String sql = "insert into person values(107,'Vani','Knp')";
		String sql = "delete from person where pid=107";
		
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			Connection conn = DriverManager.getConnection(url, "root", "root123");
			
			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			if(count > 0)
				System.out.println("Delete is succesful!!");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
