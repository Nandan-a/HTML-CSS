var dist=prompt("Enter distance in inches")

function inch(){
    document.write(parseFloat(dist)*2.54)
}